package tt1;
public class ST 
{
        public String snm;
	public String tnm;
	public ST ()
	{
		snm="--";
		tnm="--";
	}
}

