package ttgui;

import java.awt.EventQueue;


import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.SwingConstants;
import javax.swing.JLabel;

import java.awt.Image;

public class Frame1 
{

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame1 window = new Frame1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Frame1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("TimeTable Ganarator");
		frame.getContentPane().setFont(new Font("Modern No. 20", frame.getContentPane().getFont().getStyle(), frame.getContentPane().getFont().getSize()));
		frame.getContentPane().setBackground(new Color(102, 205, 170));
		frame.getContentPane().setForeground(new Color(102, 205, 170));
		frame.setBounds(100, 100, 1360, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Click Here");
		btnNewButton.setBackground(new Color(204, 204, 204));
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 23));
		btnNewButton.setForeground(new Color(51, 0, 204));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnNewButton.setBounds(602, 548, 152, 32);
		frame.getContentPane().add(btnNewButton);
		
		JLabel label = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/timetable_logo.png")).getImage();
		label.setIcon(new ImageIcon(img));
		label.setBounds(408, 11, 569, 451);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel = new JLabel("WELCOME");
		lblNewLabel.setFont(new Font("Snap ITC", Font.PLAIN, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(548, 456, 275, 50);
		frame.getContentPane().add(lblNewLabel);
	}
}
