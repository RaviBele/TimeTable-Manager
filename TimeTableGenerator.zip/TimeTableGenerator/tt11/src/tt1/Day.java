package tt1;
public class Day {
   public ST sub[]=new ST[4];	
	public int flg[]=new int[4];
	public int slot[]=new int[4];

	public Day()
	{
		for(int i=0;i<4;i++)
		{
			sub[i]=new ST();
		}
	}
	
	public void setFlag()
	{
		for(int i=0;i<4;i++)
			flg[i]=0;
	}
	
	public void setSlot(int min)
	{
		int set=min;
		for (int i=0;i<4;i++)
		{
			slot[i]=set;
			set=set+1;
		}
	}
}

