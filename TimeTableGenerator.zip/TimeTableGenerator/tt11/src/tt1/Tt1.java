package tt1;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Random;
import javax.swing.JOptionPane;
public class Tt1
{	
   public Connection con;
   public Statement stmt;
   public ResultSet rs;

    /*void connectDB()
    {
        try
        {
            Class.forName("org.sqlite.JDBC");
            String path="C:\\Users\\india\\Desktop\\TimeTable";
            con = DriverManager.getConnection("jdbc:sqlite:"+path);
            stmt= con.createStatement();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Problem with connection of database");
            e.printStackTrace();
        }
    }*/

	public static void main(String a[])
	{
            Connection con;
            Statement stmt;
            ResultSet rs;
            try
        {
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:src\\tt1\\TimeTable");
            stmt= con.createStatement();
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Problem with connection of database");
        }
		Day d2[]=new Day[5];
		Day d3[]=new Day[5];
		
		ST s2[]=new ST[6];
		ST s3[]=new ST[6];
		Random r1=new Random();
		Random r2=new Random();	
		int m,n;
		
		for(int i=0;i<6;i++)
		{
			s2[i]=new ST();
			s3[i]=new ST();	
			s2[i].snm="SY"+i;
			s2[i].tnm="T"+i;
			s3[i].snm="TY"+i;
			s3[i].tnm="T"+i;
		}

		
		/*s2[0].snm="S1";
		s2[1]="S2";
		s2[2]="S3";
		s2[3]="S4";
		s2[4]="S5";
		s2[5]="S6";*/
		System.out.println("Subject stored");

		
		for(int i=0;i<5;i++)
			{
				d2[i]=new Day();d2[i].setFlag();d2[i].setSlot(2);
				d3[i]=new Day();d3[i].setFlag();d3[i].setSlot(0);
			}
		System.out.println("Flag reset");


		for(int i=0;i<6;i++)
		{
			for(int j=0;j<3;)
			{
				m=r1.nextInt(5);
				n=r2.nextInt(4);
				if(m>=0 && m<=4 && n>=0 && n<=3)
				{
					if(d2[m].flg[n]==0)
					{	
						int ck=0;
						for(ck=0;ck<4;ck++)
						{
							if(d2[m].sub[ck]==s2[i])
							break;
						}
						if(ck==4)
						{d2[m].sub[n]=s2[i]; d2[m].flg[n]=1;
						j++;}
					}
				}
			}
		}

		System.out.println("\n\n\nSY TIME TABLE\n\n\n");
		

		for(int i=0;i<4;i++)
		{
			System.out.println((i+2)+"\t");
			for(int j=0;j<5;j++)
				System.out.print("\t"+d2[j].sub[i].snm+"-"+d2[j].sub[i].tnm);
			System.out.println();
		}


		for(int i=0;i<6;i++)
		{
			for(int j=0;j<3;)
			{
				m=r1.nextInt(5);
				n=r2.nextInt(4);
				if(m>=0 && m<=4 && n>=0 && n<=3)
				{
					if(d3[m].flg[n]==0)
					{	
						int ck=0;
						for(ck=0;ck<4;ck++)
						{
							if(d3[m].sub[ck]==s3[i])
							break;
						}
						
						
						if(ck==4)
						{
							
							if(n>=1)
							{
									/*if( n>2 && d2[m].sub[n-2].tnm!=s3[i].tnm && d2[m].sub[n-1].tnm!=s3[i].tnm)
									{	if(n==3 && d2[m].sub[n-3].tnm!=s3[i].tnm)
										{	
											d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;
										}
										else
										{
											d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;	
										}
									}
									else
									{
										if(d2[m].sub[n+1].tnm!=s3[i].tnm)
										{d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;}
									}*/
									if(d2[m].sub[n-1].tnm!=s3[i].tnm)
									{	if( n>2 && d2[m].sub[n-2].tnm!=s3[i].tnm)
										{
											if(n==3 && d2[m].sub[n-3].tnm!=s3[i].tnm)
											{d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;}
											else
											{d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;}
										}
										else
										{
											d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;
										}
									}
									else
									{
										d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;

									}
							}
							else
							{
								d3[m].sub[n]=s3[i]; d3[m].flg[n]=1;j++;
							}
						}
							
					}
				}
			}
		}

		
		
		System.out.println("\n\n\nTY TIME TABLE\n\n\n");
		
		for(int i=0;i<4;i++)
		{
			System.out.println(i+"\t");
			for(int j=0;j<5;j++)
				System.out.print("\t"+d3[j].sub[i].snm+"-"+d3[j].sub[i].tnm);
			System.out.println();
		}
		
	}
}
